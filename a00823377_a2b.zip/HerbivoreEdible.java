package ca.bcit.comp2526.a2a;

/**
 * A Plant can eat this.
 * @author Jacky
 * @version a2b
 */
public interface HerbivoreEdible {

}
