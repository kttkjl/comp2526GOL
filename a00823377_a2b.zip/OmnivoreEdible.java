package ca.bcit.comp2526.a2a;

/**
 * Omnivores can eat this.
 * @author Jacky
 * @version a2b
 */
public interface OmnivoreEdible {

}
