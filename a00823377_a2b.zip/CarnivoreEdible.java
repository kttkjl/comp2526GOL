package ca.bcit.comp2526.a2a;

/**
 * Carnivore can eat this.
 * @author Jacky
 * @version a2b
 */
public interface CarnivoreEdible {

}
